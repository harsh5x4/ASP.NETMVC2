﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Demo1.Models
{
    public class MyDataContext
    {
        public static List<Contact> ContactList = new List<Contact>()
        {
            new Contact(){Id=1001, Name="Ram", Mobile="12345",Email="ram@gmail.com"},
            new Contact(){Id=1002, Name="Shyam", Mobile="67890",Email="shyam@gmail.com"},
            new Contact(){Id=1003, Name="Suresh", Mobile="23456",Email="suresh@gmail.com"},
            new Contact(){Id=1004, Name="Mahesh", Mobile="78901",Email="mahesh@gmail.com"},
            new Contact(){Id=1005, Name="Karan", Mobile="34567",Email="karan@gmail.com"},
        };
    }
}